package sp.senai.br.wineappraiser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Alteracao extends AppCompatActivity {

    //IP do servidor debanco de dados
    String sIP = "192.168.15.21";
    EditText etQtdA, etProdutoA;
    String sId="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alteracao);
        etProdutoA   = findViewById(R.id.etProdutoA);
        etQtdA   = findViewById(R.id.etQtdA);
        //Cria uma política de segurança para permitir
        //a conexão com o banco.
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().
                        permitAll().build();
        StrictMode.setThreadPolicy(policy);
        //Pega o parametro enviado pela activity
        sId = getIntent().getStringExtra("id");
        carregar(sId);

    }
    public void carregar(String sId){
        try{
            //Chamada do php para fazer a busca de dados
            URL site = new URL("http://"+sIP+"/lista/buscarId.php?id="+sId);
            HttpURLConnection conexao =
                    (HttpURLConnection) site.openConnection();
            conexao.connect();
            InputStream entradaDados = conexao.getInputStream();
            /*BufferedReader é uma classe que lê o texto
             * de um floxo de entrada de caracteres e
             * armazena em buffer para fornecer uma leitura
             * mais eficiente*/
            BufferedReader leitor = new BufferedReader(
                    new InputStreamReader(entradaDados));
            String sLinha = leitor.readLine();
            /*A classe StringBuilder permite criar e manipular
             * dados de String dinamicamente, ou seja, permite
             * criar várias Strings modificáveis*/
            StringBuilder decodificador = new StringBuilder();
            decodificador.append(sLinha);
            String stringJSON = decodificador.toString();
            JSONArray saidaJson = new JSONArray(stringJSON);
            for(int contador = 0; contador < saidaJson.length(); contador++){
                JSONObject linhaJson = saidaJson.getJSONObject(contador);
                //pega cada linha do JSON e gera um objeto contendo
                //o id, nome e nota
                baseArrayList registro = new baseArrayList();
                etProdutoA.setText(linhaJson.getString("produto"));
                etQtdA.setText(Integer.parseInt(
                        linhaJson.getString("quantidade")));
            }
        }catch (IOException e){
            e.printStackTrace();
        }catch (JSONException e){
            throw new RuntimeException(e);
        }
    }
    public void salvarA(View s){
        try{
            URL site = new URL("http://"+sIP+
                    "/lista/atualizarDados.php?"+
                    "id="+sId+
                    "&produto="+etProdutoA.getText().toString()+
                    "&quantidade="+etQtdA.getText().toString());

            HttpURLConnection conexao =
                    (HttpURLConnection) site.openConnection();
            conexao.connect();
            conexao.getInputStream();
            Intent it = new Intent(Alteracao.this,
                    MainActivity.class);
            startActivity(it);
            finish();
        }catch(MalformedURLException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

}