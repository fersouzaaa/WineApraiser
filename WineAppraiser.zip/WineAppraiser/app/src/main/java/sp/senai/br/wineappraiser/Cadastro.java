package sp.senai.br.wineappraiser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Cadastro extends AppCompatActivity {

    //IP do servidor debanco de dados
    String sIP = "192.168.15.21";
    EditText etProduto, etQtd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        etProduto   = findViewById(R.id.etProduto);
        etQtd   = findViewById(R.id.etQtd);
        //Cria uma política de segurança para permitir
        //a conexão com o banco.
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().
                        permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }
    public void salvar(View s){
        try{
            URL site = new URL("http://"+sIP+
                    "/lista/inserirDados.php?"+
                    "produto="+etProduto.getText().toString()+
                    "&quantidade="+etQtd.getText().toString());

            HttpURLConnection conexao =
                    (HttpURLConnection) site.openConnection();
            conexao.connect();
            conexao.getInputStream();
            Intent it = new Intent(Cadastro.this,
                                          MainActivity.class);
            startActivity(it);
            finish();
        }catch(MalformedURLException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}