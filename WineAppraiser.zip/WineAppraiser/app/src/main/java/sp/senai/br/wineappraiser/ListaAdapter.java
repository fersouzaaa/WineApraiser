package sp.senai.br.wineappraiser;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class ListaAdapter extends ArrayAdapter<baseArrayList> {

    private List<baseArrayList> itens;
    public ListaAdapter(Context context, int resource,
                        List<baseArrayList> itens) {
        super(context, resource, itens);
        this.itens=itens;
    }

    @Override
    public View getView(int position,View convertView, ViewGroup parent) {
        View v = convertView;
        if(v==null){
            Context ctx = getContext();
            LayoutInflater li = (LayoutInflater)
                    ctx.getSystemService(
                    Context.LAYOUT_INFLATER_SERVICE);
            v = li.inflate(R.layout.layout_lista,null);
        }
        baseArrayList base = itens.get(position);
        if(base!=null){
            ((TextView) v.findViewById(R.id.ckProduto)).setText(base.produto);
            ((TextView) v.findViewById(R.id.tvQntd)).setText(base.quantidade);
        }
        return v;
    }
}
