package sp.senai.br.wineappraiser;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView lvLista;
    List<baseArrayList> arrayLista;
    String sIP = "192.168.15.21";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Cria uma política de segurança para permitir
        //a conexão com o banco.
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().
                        permitAll().build();
        StrictMode.setThreadPolicy(policy);
        lvLista = findViewById(R.id.lvLista);

        if(arrayLista==null){
            arrayLista=new ArrayList<>();
        }
        preencheLista();
        lvLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String sId=arrayLista.get(i).id;
                Intent altera = new Intent(MainActivity.this,
                                           Alteracao.class);
                altera.putExtra("id",sId);
                startActivity(altera);
                finish();
            }
        });


    }
    public void novo(View n){
        Intent it = new Intent(MainActivity.this,
                Cadastro.class);
        startActivity(it);
        finish();
    }
    public void preencheLista(){
        try{
            arrayLista.clear();
            //Chamda do php para fazer a busca de dados
            URL site = new URL("http://"+sIP+"/lista/buscarDados.php");
            HttpURLConnection conexao =
                    (HttpURLConnection) site.openConnection();
            conexao.connect();
            InputStream entradaDados = conexao.getInputStream();
            /*BufferedReader é uma classe que lê o texto
            * de um floxo de entrada de caracteres e
            * armazena em buffer para fornecer uma leitura
            * mais eficiente*/
            BufferedReader leitor = new BufferedReader(
                    new InputStreamReader(entradaDados));
            String sLinha;
            /*A classe StringBuilder permite criar e manipular
            * dados de String dinamicamente, ou seja, permite
            * criar várias Strings modificáveis*/
            StringBuilder decodificador = new StringBuilder();
            while ((sLinha = leitor.readLine()) != null){
                decodificador.append(sLinha);
            }
            String stringJSON = decodificador.toString();
            JSONArray saidaJson = new JSONArray(stringJSON);
            //Cria o cabeçalho da lista

            for(int contador = 0; contador < saidaJson.length(); contador++){
                JSONObject linhaJson = saidaJson.getJSONObject(contador);
                //pega cada linha do JSON e gera um objeto contendo
                //o id, nome e nota
                baseArrayList registro = new baseArrayList();
                registro.id   = linhaJson.getString("id");
                registro.quantidade = linhaJson.getString("quantidade");
                registro.produto = linhaJson.getString("produto");
                arrayLista.add(registro);
            }
            //Adaptando as informações do arraylist no ListView
            ListaAdapter adpt = new ListaAdapter(getBaseContext(),
                    R.layout.layout_lista, arrayLista);
            lvLista.setAdapter(adpt);
        }catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }catch (JSONException e){
            throw new RuntimeException(e);
        }
    }
}